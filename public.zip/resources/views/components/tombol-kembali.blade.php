<a {{ $attributes->merge(['class' => 'btn btn-outline-secondary']) }}>
    Kembali
</a>