<div class="row">
    <div class="col">
        <x-tombol-tambah label="Tambah User" href="{{ route('user.create') }}" />
    </div>
    <div class="col">
        <x-form-search placeholder="Cari nama/email user..." />
    </div>
</div>