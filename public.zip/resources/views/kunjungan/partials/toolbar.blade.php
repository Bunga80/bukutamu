<div class="row">
    <div class="col">
        <x-tombol-tambah label="Tambah Kunjungan" href="{{ route('kunjungan.create') }}" />
    </div>
    <div class="col">
        <x-form-search placeholder="Cari nama tamu/instansi..." />
    </div>
</div>