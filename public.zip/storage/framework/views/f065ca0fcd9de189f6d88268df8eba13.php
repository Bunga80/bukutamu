<?php if (isset($component)) { $__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <tr>
            <th style="width: 3%; text-align: center;">#</th>
            <th style="width: 10%; white-space: nowrap;">Kode Tamu</th>
            <th style="width: 10%; white-space: nowrap;">Tanggal</th>
            <th style="width: 13%;">Nama Tamu</th>
            <th style="width: 18%;">Email/No.Telp</th>
            <th style="width: 13%;">Instansi</th>
            <th style="width: 16%;">Keperluan</th>
            <th style="width: 6%; text-align: center;">Aksi</th>
        </tr>
     <?php $__env->endSlot(); ?>
    
    <?php $__empty_1 = true; $__currentLoopData = $kunjungans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kunjungan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td style="text-align: center;"><?php echo e($kunjungans->firstItem() + $index); ?></td>
            <td style="white-space: nowrap;"><strong><?php echo e($kunjungan->kode_tamu); ?></strong></td>
            <td style="white-space: nowrap;"><?php echo e(\Carbon\Carbon::parse($kunjungan->tanggal)->format('d-m-Y')); ?></td>
            <td><?php echo e($kunjungan->nama); ?></td>
            <td style="word-break: break-word;"><?php echo e($kunjungan->kontak); ?></td>
            <td><?php echo e($kunjungan->instansi); ?></td>
            <td style="word-wrap: break-word;"><?php echo e($kunjungan->keperluan); ?></td>
            <td style="text-align: center;">
                <div class="d-flex gap-1 justify-content-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage kunjungan')): ?>
                        <?php if (isset($component)) { $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-aksi','data' => ['href' => ''.e(route('kunjungan.show', $kunjungan->id)).'','type' => 'show']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-aksi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('kunjungan.show', $kunjungan->id)).'','type' => 'show']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $attributes = $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $component = $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-aksi','data' => ['href' => ''.e(route('kunjungan.edit', $kunjungan->id)).'','type' => 'edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-aksi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('kunjungan.edit', $kunjungan->id)).'','type' => 'edit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $attributes = $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $component = $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete kunjungan')): ?>
                        <?php if (isset($component)) { $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-aksi','data' => ['href' => ''.e(route('kunjungan.destroy', $kunjungan->id)).'','type' => 'delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-aksi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('kunjungan.destroy', $kunjungan->id)).'','type' => 'delete']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $attributes = $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $component = $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="9" class="text-center">
                <div class="alert alert-danger mb-0">
                    Data Kunjungan belum tersedia.
                </div>
            </td>
        </tr>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19)): ?>
<?php $attributes = $__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19; ?>
<?php unset($__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19)): ?>
<?php $component = $__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19; ?>
<?php unset($__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\kunjungan\partials\list-kunjungan.blade.php ENDPATH**/ ?>