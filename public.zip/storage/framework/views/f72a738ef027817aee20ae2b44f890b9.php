<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-danger'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\danger-button.blade.php ENDPATH**/ ?>