<div class="table-responsive">
    <table <?php echo e($attributes->merge(['class' => 'table table-hover table-bordered'])); ?>>
        <thead>
            <?php echo e($header); ?>

        </thead>
        <tbody>
            <?php echo e($slot); ?>

        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\table-list.blade.php ENDPATH**/ ?>