<?php if (isset($component)) { $__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <th>#</th>
        <th>Nama</th>
        <th>Email / Username</th>
        <th>Role</th>
        <th>&nbsp;</th>
     <?php $__env->endSlot(); ?>

    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            [$role] = $user->getRoleNames();
        ?>
        <tr>
            <td><?php echo e($users->firstItem() + $index); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td>
                <span class="badge bg-primary">
                    <?php echo e(ucwords($role)); ?>

                </span>
            </td>
            <td>
                <?php if (isset($component)) { $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-aksi','data' => ['href' => route('user.edit', $user->id),'type' => 'edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-aksi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('user.edit', $user->id)),'type' => 'edit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $attributes = $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $component = $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-aksi','data' => ['href' => route('user.destroy', $user->id),'type' => 'delete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-aksi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('user.destroy', $user->id)),'type' => 'delete']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $attributes = $__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__attributesOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4)): ?>
<?php $component = $__componentOriginal62ee50c781f414a3a4fe9b6134e276e4; ?>
<?php unset($__componentOriginal62ee50c781f414a3a4fe9b6134e276e4); ?>
<?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center">
                <div class="alert alert-danger">
                    Data user belum tersedia.
                </div>
            </td>
        </tr>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19)): ?>
<?php $attributes = $__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19; ?>
<?php unset($__attributesOriginalace4d1b2e22e971ae2a2b53aefed4e19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19)): ?>
<?php $component = $__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19; ?>
<?php unset($__componentOriginalace4d1b2e22e971ae2a2b53aefed4e19); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\user\partials\list-user.blade.php ENDPATH**/ ?>