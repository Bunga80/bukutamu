<form action="?" method="get">
    <div class="input-group">
        <input
            <?php echo e($attributes->merge(['class' => 'form-control', 'type' => 'text', 'name' => 'search', 'value' => request('search') ])); ?>>
        <button class="btn btn-primary" type="submit">
            <i class="bi bi-search"></i>
        </button>
    </div>
</form><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\form-search.blade.php ENDPATH**/ ?>