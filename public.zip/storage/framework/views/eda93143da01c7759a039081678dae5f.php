<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve(['titlePage' => __('Laporan Kunjungan')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="container-fluid">

    <div class="row">
        <!-- Laporan Bulanan -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100" style="border-top: 4px solid #007bff;">
                <div class="card-body">
                    <h5 class="card-title mb-4">Buat Laporan Bulanan</h5>
                    <form action="<?php echo e(route('laporan.bulanan')); ?>" method="GET" target="_blank">
                        <div class="mb-3">
                            <label for="bulan" class="form-label">Bulan</label>
                            <select class="form-control" id="bulan" name="month" required>
                                <option value="">Pilih Bulan:</option>
                                <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($m); ?>" <?php echo e(date('n') == $m ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::create()->month($m)->translatedFormat('F')); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="tahun_bulanan" class="form-label">Tahun</label>
                            <select class="form-control" id="tahun_bulanan" name="year" required>
                                <option value="">Pilihan Tahun:</option>
                                <?php $__currentLoopData = range(date('Y') - 5, date('Y')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($y); ?>" <?php echo e(date('Y') == $y ? 'selected' : ''); ?>>
                                        <?php echo e($y); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-print"></i> Cetak
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Laporan Tahunan -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100" style="border-top: 4px solid #007bff;">
                <div class="card-body">
                    <h5 class="card-title mb-4">Buat Laporan Tahunan</h5>
                    <form action="<?php echo e(route('laporan.tahunan')); ?>" method="GET" target="_blank">
                        <div class="mb-3">
                            <label for="tahun_tahunan" class="form-label">Tahun</label>
                            <select class="form-control" id="tahun_tahunan" name="year" required>
                                <option value="">Pilih Tahun:</option>
                                <?php $__currentLoopData = range(date('Y') - 5, date('Y')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($y); ?>" <?php echo e(date('Y') == $y ? 'selected' : ''); ?>>
                                        <?php echo e($y); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <!-- Spacer untuk menyamakan tinggi dengan form bulanan -->
                        <div class="mb-3" style="height: 70px;"></div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-print"></i> Cetak
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border-radius: 8px;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    .card-title {
        font-weight: 600;
        color: #333;
    }
    
    .form-control {
        border-radius: 5px;
        border: 1px solid #ced4da;
    }
    
    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
    }
    
    .btn {
        border-radius: 5px;
        padding: 10px;
        font-weight: 600;
    }
    
    .form-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 8px;
    }
</style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\laporan\form.blade.php ENDPATH**/ ?>