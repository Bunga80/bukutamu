<?php
    $message = session('success') ?? session('error');
    $type = session('success') ? 'success' : 'danger';
?>

<?php if($message): ?>
    <div
        <?php echo e($attributes->merge([
            'class' => 'form-control alert alert-dismissible fade show alert-' . $type,
            'role' => 'alert',
        ])); ?>>
        <?php echo e($message); ?>

    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\notif-alert.blade.php ENDPATH**/ ?>