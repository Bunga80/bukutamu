<div>
    <!-- He who is contented is rich. - Laozi -->
</div><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\main-layout.blade.php ENDPATH**/ ?>