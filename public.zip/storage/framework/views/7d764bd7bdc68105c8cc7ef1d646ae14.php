<div class="row">
    <div class="col">
        <?php if (isset($component)) { $__componentOriginal3a745a710bf6697a78ab5f537a2a3a04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3a745a710bf6697a78ab5f537a2a3a04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tombol-tambah','data' => ['label' => 'Tambah User','href' => ''.e(route('user.create')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tombol-tambah'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Tambah User','href' => ''.e(route('user.create')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3a745a710bf6697a78ab5f537a2a3a04)): ?>
<?php $attributes = $__attributesOriginal3a745a710bf6697a78ab5f537a2a3a04; ?>
<?php unset($__attributesOriginal3a745a710bf6697a78ab5f537a2a3a04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3a745a710bf6697a78ab5f537a2a3a04)): ?>
<?php $component = $__componentOriginal3a745a710bf6697a78ab5f537a2a3a04; ?>
<?php unset($__componentOriginal3a745a710bf6697a78ab5f537a2a3a04); ?>
<?php endif; ?>
    </div>
    <div class="col">
        <?php if (isset($component)) { $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-search','data' => ['placeholder' => 'Cari nama/email user...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Cari nama/email user...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $attributes = $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $component = $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\user\partials\toolbar.blade.php ENDPATH**/ ?>