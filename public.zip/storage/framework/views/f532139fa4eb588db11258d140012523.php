<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href', 'type']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href', 'type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php switch($type):
    case ('show'): ?>
        <a href="<?php echo e($href); ?>" class="btn btn-sm btn-info">
            <i class="bi bi-card-list"></i>
        </a>
        <?php break; ?>

    <?php case ('edit'): ?>
        <a href="<?php echo e($href); ?>" class="btn btn-sm btn-warning">
            <i class="bi bi-pencil-square"></i>
        </a>
        <?php break; ?>

    <?php case ('delete'): ?>
        <button type="button" data-url="<?php echo e($href); ?>" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
            <i class="bi bi-x-circle"></i>
        </button>
        <?php break; ?>
<?php endswitch; ?><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\tombol-aksi.blade.php ENDPATH**/ ?>