<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <th style="width: 30%">Kode Tamu</th>
            <td><strong><?php echo e($kunjungan->kode_tamu); ?></strong></td>
        </tr>
        <tr>
            <th>Tanggal</th>
            <td><?php echo e(\Carbon\Carbon::parse($kunjungan->tanggal)->format('d-m-Y')); ?></td>
        </tr>
        <tr>
            <th style="width: 30%">Nama Tamu</th>
            <td><?php echo e($kunjungan->nama); ?></td>
        </tr>
        <tr>
            <th>Email/No.Telp</th>
            <td><?php echo e($kunjungan->kontak); ?></td>
        </tr>
        <tr>
            <th>Instansi</th>
            <td><?php echo e($kunjungan->instansi); ?></td>
        </tr>
        <tr>
            <th>Keperluan</th>
            <td><?php echo e($kunjungan->keperluan); ?></td>
        </tr>
        <tr>
            <th>Terakhir Diperbarui</th>
            <td><?php echo e($kunjungan->updated_at->timezone('Asia/Jakarta')->translatedFormat('d F Y, H:i')); ?> WIB</td>
        </tr>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\kunjungan\partials\info-data-kunjungan.blade.php ENDPATH**/ ?>