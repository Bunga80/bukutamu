<a <?php echo e($attributes->merge(['class' => 'btn btn-outline-secondary'])); ?>>
    Kembali
</a><?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\tombol-kembali.blade.php ENDPATH**/ ?>