<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-outline-secondary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\Buku-Tamu\resources\views\components\secondary-button.blade.php ENDPATH**/ ?>